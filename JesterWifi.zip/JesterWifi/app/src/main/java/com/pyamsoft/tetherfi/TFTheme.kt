/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.tetherfi

import android.app.Activity
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.annotation.CheckResult
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import com.pyamsoft.pydroid.theme.PYDroidTheme
import com.pyamsoft.pydroid.ui.haptics.LocalHapticManager
import com.pyamsoft.pydroid.ui.haptics.rememberHapticManager
import com.pyamsoft.pydroid.ui.theme.Theming
import com.pyamsoft.pydroid.ui.uri.LocalExternalUriHandler
import com.pyamsoft.pydroid.ui.uri.rememberExternalUriHandler
import com.pyamsoft.pydroid.util.AppDispatchers

@Composable
@ChecksSdkIntAtLeast(Build.VERSION_CODES.S)
private fun rememberCanUseDynamic(isMaterialYou: Boolean): Boolean {
  return remember(isMaterialYou) { Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && isMaterialYou }
}

@Composable
@CheckResult
private fun themeColors(
    activity: Activity,
    isDarkMode: Boolean,
    isMaterialYou: Boolean,
): ColorScheme {
  // Jester WiFi always uses the black and purple theme
  return remember { jesterColorScheme() }
}

@CheckResult
private fun jesterColorScheme(): ColorScheme {
  val primary = Color(0xFFB57CFF)
  val primaryContainer = Color(0xFF4A1C8C)
  return darkColorScheme(
      primary = primary,
      onPrimary = Color(0xFF1E0042),
      primaryContainer = primaryContainer,
      onPrimaryContainer = Color(0xFFEBDCFF),
      inversePrimary = Color(0xFF6F2DD8),
      secondary = Color(0xFFCDB4F5),
      onSecondary = Color(0xFF2B1650),
      secondaryContainer = Color(0xFF3B2A5C),
      onSecondaryContainer = Color(0xFFEBDCFF),
      tertiary = Color(0xFFE0A8FF),
      onTertiary = Color(0xFF3A0057),
      tertiaryContainer = Color(0xFF55207A),
      onTertiaryContainer = Color(0xFFF6D9FF),
      error = Color(0xFFFFB4AB),
      errorContainer = Color(0xFF93000A),
      onError = Color(0xFF690005),
      onErrorContainer = Color(0xFFFFDAD6),
      background = Color(0xFF000000),
      onBackground = Color(0xFFEDE4F7),
      surface = Color(0xFF0A0710),
      onSurface = Color(0xFFEDE4F7),
      inverseSurface = Color(0xFFEDE4F7),
      inverseOnSurface = Color(0xFF1B1524),
      surfaceVariant = Color(0xFF211833),
      onSurfaceVariant = Color(0xFFCBBFE0),
      outline = Color(0xFF8A7AA6),
      outlineVariant = Color(0xFF3A2D52),
      surfaceTint = primary,
      scrim = Color(0xFF000000),
  )
}

@Composable
fun ComponentActivity.TFTheme(
    dispatchers: AppDispatchers,
    theme: Theming.Mode,
    isMaterialYou: Boolean,
    content: @Composable () -> Unit,
) {
  val self = this

  val hapticManager =
      rememberHapticManager(
          dispatchers = dispatchers,
      )
  val isDarkMode = theme.getSystemDarkMode()
  val uriHandler = rememberExternalUriHandler()

  PYDroidTheme(
      colorScheme = themeColors(self, isDarkMode, isMaterialYou),
  ) {
    CompositionLocalProvider(
        // We update the LocalContentColor to match our onBackground. This allows the default
        // content color to be more appropriate to the theme background
        LocalContentColor provides MaterialTheme.colorScheme.onBackground,

        // We provide the local haptic manager since PYDroid makes it optional
        LocalHapticManager provides hapticManager,

        // We provide external URI handler
        LocalExternalUriHandler provides uriHandler,

        // And the content, finally
        content = content,
    )
  }
}

@Composable
@CheckResult
fun Theming.Mode.getSystemDarkMode(): Boolean {
  val self = this
  val isDarkMode =
      remember(self) {
        when (self) {
          Theming.Mode.LIGHT -> false
          Theming.Mode.DARK -> true
          Theming.Mode.SYSTEM -> null
        }
      }

  return isDarkMode ?: isSystemInDarkTheme()
}
