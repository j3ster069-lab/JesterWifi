# Jester WiFi

Share your Android device's Internet connection with other devices (Wi-Fi Direct + proxy).

Jester WiFi is a modified build of the open-source TetherFi / TetherFuseNet project by pyamsoft,
used under the Apache License 2.0. See the LICENSE file.
