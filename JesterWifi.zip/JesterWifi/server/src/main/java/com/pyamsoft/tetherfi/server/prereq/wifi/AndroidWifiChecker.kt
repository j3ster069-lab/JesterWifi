/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.tetherfi.server.prereq.wifi

import android.content.Context
import android.net.wifi.WifiManager
import androidx.core.content.getSystemService
import com.pyamsoft.pydroid.core.LintIgnoreTooGenericExceptionCaught
import com.pyamsoft.pydroid.core.requireNotNull
import com.pyamsoft.pydroid.util.AppDispatchers
import com.pyamsoft.pydroid.util.ifNotCancellation
import com.pyamsoft.tetherfi.core.Timber
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.withContext

@Singleton
internal class AndroidWifiChecker
@Inject
internal constructor(
    appContext: Context,
    private val dispatchers: AppDispatchers,
) : WifiChecker {

  private val manager by lazy {
    appContext.getSystemService<WifiManager>().requireNotNull { "WifiManager service is missing" }
  }

  override suspend fun isWifiOn(): Boolean =
      withContext(context = dispatchers.default) {
        try {
          return@withContext manager.isWifiEnabled
        } catch (@LintIgnoreTooGenericExceptionCaught e: Throwable) {
          e.ifNotCancellation {
            Timber.e(e) { "Error trying to access isWifiEnabled" }
            return@withContext false
          }
        }
      }
}
