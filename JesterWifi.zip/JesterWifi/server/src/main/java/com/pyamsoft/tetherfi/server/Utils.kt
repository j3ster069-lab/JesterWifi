/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.tetherfi.server

import androidx.annotation.CheckResult

/**
 * What the fuck is this
 * https://stackoverflow.com/questions/10006459/regular-expression-for-ip-address-validation
 *
 * Tests if a given string is an IPv4 address
 */
@JvmField
val IPV4_ADDRESS_REGEX =
    """^(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))$"""
        .toRegex()

@CheckResult
fun isIp4Address(hostOrIp: String): Boolean {
  return IPV4_ADDRESS_REGEX.matches(hostOrIp)
}

@CheckResult
fun isIp6Address(hostOrIp: String): Boolean {
  return hostOrIp.contains(':')
}

@CheckResult
fun isIpAddress(hostOrIp: String): Boolean {
  return isIp4Address(hostOrIp) || isIp6Address(hostOrIp)
}
