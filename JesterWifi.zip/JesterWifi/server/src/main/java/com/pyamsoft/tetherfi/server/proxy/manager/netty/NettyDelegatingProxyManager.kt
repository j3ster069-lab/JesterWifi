/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.tetherfi.server.proxy.manager.netty

import android.net.Network
import com.pyamsoft.pydroid.util.AppDispatchers
import com.pyamsoft.tetherfi.server.ServerSocketTimeout
import com.pyamsoft.tetherfi.server.broadcast.BroadcastNetworkStatus
import com.pyamsoft.tetherfi.server.clients.AllowedClients
import com.pyamsoft.tetherfi.server.clients.BlockedClients
import com.pyamsoft.tetherfi.server.clients.ClientResolver
import com.pyamsoft.tetherfi.server.network.SocketBinder
import com.pyamsoft.tetherfi.server.proxy.SocketTagger
import com.pyamsoft.tetherfi.server.proxy.session.netty.SuspendingNettyDelegatingProxy
import com.pyamsoft.tetherfi.server.proxy.session.netty.SuspendingNettyProxy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

internal class NettyDelegatingProxyManager
internal constructor(
    socketBinder: SocketBinder,
    private val blockedClients: BlockedClients,
    private val clientResolver: ClientResolver,
    private val allowedClients: AllowedClients,
    private val isDebug: Boolean,
    private val socketTagger: SocketTagger,
    private val hostConnection: BroadcastNetworkStatus.ConnectionInfo.Connected,
    private val port: Int,
    private val isHttpEnabled: Boolean,
    private val isSocksEnabled: Boolean,
    private val serverSocketTimeout: ServerSocketTimeout,
    private val dispatchers: AppDispatchers,
) :
    NettyProxyManager(
        socketBinder = socketBinder,
        hostConnection = hostConnection,
        port = port,
    ) {

  override fun CoroutineScope.provideProxy(
      network: Network?,
      onOpened: suspend () -> Unit,
      onClosing: suspend () -> Unit,
      onClosed: () -> Unit,
      onError: suspend (Throwable) -> Unit,
  ): SuspendingNettyProxy {
    return SuspendingNettyDelegatingProxy(
        isDebug = isDebug,
        blockedClients = blockedClients,
        allowedClients = allowedClients,
        clientResolver = clientResolver,
        host = hostConnection.hostName,
        port = port,
        socketTagger = socketTagger,
        isHttpEnabled = isHttpEnabled,
        isSocksEnabled = isSocksEnabled,
        dispatchers = dispatchers,
        serverSocketTimeout = serverSocketTimeout,
        androidPreferredNetwork = network,
        onOpened = { launch { onOpened() } },
        onClosing = { launch { onClosing() } },
        onClosed = { onClosed() },
        onError = { launch { onError(it) } },
    )
  }
}
