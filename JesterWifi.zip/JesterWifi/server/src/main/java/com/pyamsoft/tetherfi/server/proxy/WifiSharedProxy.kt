/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:LintIgnoreTooManyFunctions

package com.pyamsoft.tetherfi.server.proxy

import androidx.annotation.CheckResult
import com.pyamsoft.pydroid.bus.EventBus
import com.pyamsoft.pydroid.core.LintIgnoreLongMethod
import com.pyamsoft.pydroid.core.LintIgnoreTooGenericExceptionCaught
import com.pyamsoft.pydroid.core.LintIgnoreTooManyFunctions
import com.pyamsoft.pydroid.core.ThreadEnforcer
import com.pyamsoft.pydroid.util.AppDispatchers
import com.pyamsoft.pydroid.util.ifNotCancellation
import com.pyamsoft.tetherfi.core.AppDevEnvironment
import com.pyamsoft.tetherfi.core.Timber
import com.pyamsoft.tetherfi.server.BaseServer
import com.pyamsoft.tetherfi.server.ProxyPreferences
import com.pyamsoft.tetherfi.server.ServerInternalApi
import com.pyamsoft.tetherfi.server.broadcast.BroadcastNetworkStatus
import com.pyamsoft.tetherfi.server.clients.ClientEraser
import com.pyamsoft.tetherfi.server.clients.StartedClients
import com.pyamsoft.tetherfi.server.event.ServerShutdownEvent
import com.pyamsoft.tetherfi.server.lock.Locker
import com.pyamsoft.tetherfi.server.proxy.manager.ProxyManager
import com.pyamsoft.tetherfi.server.status.RunningStatus
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

@Singleton
internal class WifiSharedProxy
@Inject
internal constructor(
    @param:ServerInternalApi private val factory: ProxyManager.Factory,
    private val enforcer: ThreadEnforcer,
    private val clientEraser: ClientEraser,
    private val startedClients: StartedClients,
    private val shutdownBus: EventBus<ServerShutdownEvent>,
    private val appEnvironment: AppDevEnvironment,
    private val preferences: ProxyPreferences,
    private val dispatchers: AppDispatchers,
    status: ProxyStatus,
) : BaseServer(status), SharedProxy {

  private val overallState = MutableStateFlow(ProxyState())

  private fun adjustState(type: SharedProxy.Type, ready: Boolean) {
    overallState.update { s ->
      when (type) {
        SharedProxy.Type.NETTY -> s.copy(netty = ready)
      }
    }
  }

  private fun readyState(type: SharedProxy.Type) {
    adjustState(type, ready = true)
  }

  private fun unreadyState(type: SharedProxy.Type) {
    adjustState(type, ready = false)
  }

  private fun resetState() {
    overallState.update { it.copy(netty = false) }
  }

  private suspend fun shutdownProxyServerWithCause(e: Throwable) {
    reset()
    status.set(RunningStatus.ProxyError(e))
    shutdownBus.emit(ServerShutdownEvent(throwable = e))
  }

  private suspend fun handleServerLoopError(e: Throwable, type: SharedProxy.Type) {
    Timber.e(e) { "Error running server loop: ${type.name}" }
    shutdownProxyServerWithCause(e)
  }

  private suspend fun beginProxyLoop(
      type: SharedProxy.Type,
      lock: Locker.Lock,
      info: BroadcastNetworkStatus.ConnectionInfo.Connected,
      isHttpEnabled: Boolean,
      isSocksEnabled: Boolean,
  ) {
    enforcer.assertOffMainThread()

    try {
      val port = preferences.listenForPortChanges().first()

      Timber.d {
        "${type.name} Begin proxy server loop: $info ($port)"
      }
      factory
          .create(
              type = type,
              info = info,
              port = port,
              isHttpEnabled = isHttpEnabled,
              isSocksEnabled = isSocksEnabled,
          )
          .loop(
              lock = lock,
              onOpened = { readyState(type) },
              onClosing = {
                // Closing, we mark as stopping early
                status.set(RunningStatus.Stopping)
                unreadyState(type)
              },
              onClosed = {
                Timber.d { "Proxy Server is Done!" }
                broadcastProxyStop()
              },
              onError = { e -> e.ifNotCancellation { handleServerLoopError(e = e, type = type) } },
          )
    } catch (@LintIgnoreTooGenericExceptionCaught e: Throwable) {
      e.ifNotCancellation { handleServerLoopError(e = e, type = type) }
    }
  }

  private suspend fun proxyLoop(
      scope: CoroutineScope,
      lock: Locker.Lock,
      info: BroadcastNetworkStatus.ConnectionInfo.Connected,
      isHttpEnabled: Boolean,
      isSocksEnabled: Boolean,
  ) {
    val fakeError = appEnvironment.isProxyFakeError
    if (fakeError.first()) {
      Timber.w { "DEBUG forcing Fake Proxy Error" }
      status.set(RunningStatus.ProxyError(RuntimeException("DEBUG: Force Fake Proxy Error")))
      return
    }

    if (!isHttpEnabled && !isSocksEnabled) {
      Timber.w { "Cannot run proxy. HTTP and SOCKS both disabled" }
      status.set(
          RunningStatus.ProxyError(RuntimeException("Must enable either HTTP or SOCKS server")),
      )
    } else {
      scope.launch(context = dispatchers.default) {
        beginProxyLoop(
            type = SharedProxy.Type.NETTY,
            lock = lock,
            info = info,
            isHttpEnabled = isHttpEnabled,
            isSocksEnabled = isSocksEnabled,
        )
      }
    }
  }

  private fun reset() {
    enforcer.assertOffMainThread()

    clientEraser.clear()
    resetState()
  }

  private fun broadcastProxyStop() {
    enforcer.assertOffMainThread()

    // Update status if we were running
    if (status.get() is RunningStatus.Running) {
      status.set(RunningStatus.Stopping)
    }

    reset()
    status.set(RunningStatus.NotRunning)
  }

  private fun CoroutineScope.watchServerReadyStatus() {
    // When all proxy bits declare they are ready, the proxy status is "ready"
    overallState
        .map { it.isReady() }
        .filter { it }
        .also { f ->
          launch(context = dispatchers.default) {
            f.collect { ready ->
              if (ready) {
                Timber.d { "Proxy has fully launched, update status!" }
                status.set(RunningStatus.Running)
              }
            }
          }
        }
  }

  private suspend fun startServer(
      lock: Locker.Lock,
      info: BroadcastNetworkStatus.ConnectionInfo.Connected,
      isHttpEnabled: Boolean,
      isSocksEnabled: Boolean,
  ) {
    try {
      // Launch a new scope so this function won't proceed to finally block until the scope is
      // completed/cancelled
      //
      // This will suspend until the proxy server loop dies
      coroutineScope {
        // Mark proxy launching
        Timber.d { "Starting proxy server ..." }
        status.set(RunningStatus.Starting, clearError = true)

        watchServerReadyStatus()

        // Notify the client connection watcher that we have started
        launch(context = dispatchers.default) { startedClients.started() }

        // Start the proxy server loop
        launch(context = dispatchers.default) {
          proxyLoop(
              scope = this,
              lock = lock,
              info = info,
              isHttpEnabled = isHttpEnabled,
              isSocksEnabled = isSocksEnabled,
          )
        }
      }
    } finally {
      Timber.d { "Stopped Proxy Server" }
    }
  }

  private suspend fun Job.stopProxyLoop() {
    status.set(RunningStatus.Stopping)
    cancelAndJoin()
  }

  @LintIgnoreLongMethod
  override suspend fun start(
      lock: Locker.Lock,
      connectionStatus: Flow<BroadcastNetworkStatus.ConnectionInfo>,
  ) =
      withContext(context = dispatchers.io) {
        // Scope local
        val mutex = Mutex()

        var proxyJob: Job? = null
        var killTimerJob: Job? = null

        // Watch the connection status
        val isHttpEnabled = preferences.listenForHttpEnabledChanges().first()
        val isSocksEnabled = preferences.listenForSocksEnabledChanges().first()

        try {

          // Launch a new scope so this function won't proceed to finally block until the scope is
          // completed/cancelled
          //
          // This will suspend until the proxy server loop dies
          coroutineScope {

            // Watch the connection status for valid info
            connectionStatus.distinctUntilChanged().collect { info ->
              when (info) {
                is BroadcastNetworkStatus.ConnectionInfo.Connected -> {
                  // Connected is good, we can launch
                  // This will re-launch any time the connection info changes

                  mutex.withLock {
                    // Kill timer, we have something now
                    killTimerJob?.cancelAndJoin()
                    killTimerJob = null

                    proxyJob?.stopProxyLoop()
                    proxyJob = null
                  }

                  // Reset old
                  reset()

                  mutex.withLock {

                    // Hold onto the job here so we can cancel it if we need to
                    proxyJob =
                        launch(context = dispatchers.default) {
                          startServer(
                              lock = lock,
                              info = info,
                              isHttpEnabled = isHttpEnabled,
                              isSocksEnabled = isSocksEnabled,
                          )
                        }
                  }
                }

                is BroadcastNetworkStatus.ConnectionInfo.Empty -> {
                  Timber.w { "Connection EMPTY, shut down Proxy" }

                  // Empty is missing the channel, bad
                  mutex.withLock {
                    proxyJob?.stopProxyLoop()
                    proxyJob = null
                  }

                  broadcastProxyStop()

                  // Mark us as starting
                  // don't clear errors if they exist
                  status.set(RunningStatus.Starting)

                  mutex.withLock {
                    // Assign kill timer when we first see EMPTY
                    if (killTimerJob == null) {
                      killTimerJob =
                          launch(context = dispatchers.default) {
                            delay(5.seconds)

                            Timber.w { "Connection has been EMPTY for too long!" }

                            // Stop the proxy again so the user can interact with UI
                            broadcastProxyStop()
                          }
                    }
                  }
                }

                is BroadcastNetworkStatus.ConnectionInfo.Error -> {
                  Timber.w { "Connection ERROR, shut down Proxy" }

                  // Error is bad, shut down the proxy
                  mutex.withLock {
                    // Kill timer, we are dead
                    killTimerJob?.cancelAndJoin()
                    killTimerJob = null

                    proxyJob?.stopProxyLoop()
                    proxyJob = null
                  }
                  broadcastProxyStop()
                }

                is BroadcastNetworkStatus.ConnectionInfo.Unchanged -> {
                  Timber.w { "UNCHANGED SHOULD NOT HAPPEN" }
                  shutdownProxyServerWithCause(UNCHANGED_SHOULD_NOT_HAPPEN_ERROR)
                }
              }
            }
          }
        } finally {
          withContext(context = NonCancellable) {
            Timber.d { "Shutting down proxy..." }

            // Kill proxy job
            mutex.withLock {
              killTimerJob?.cancelAndJoin()
              proxyJob?.stopProxyLoop()
            }

            // We will then await the onClosed() event
            // but it may never come if the proxy server is in the ERROR state,
            // so in that case fire it ourselves.
            if (overallState.value.isReady()) {
              Timber.d { "Awaiting proxy server close event..." }
            } else {
              Timber.d { "Manually firing Proxy CLOSE event!" }
              broadcastProxyStop()
            }
          }
        }
      }

  private data class ProxyState(
      val netty: Boolean = false,
  ) {

    @CheckResult
    fun isReady(): Boolean {
      return netty
    }
  }

  companion object {

    private val UNCHANGED_SHOULD_NOT_HAPPEN_ERROR =
        AssertionError("ConnectionInfo.Unchanged should never escape the server-module internals.")
  }
}
