/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.tetherfi.service.prereq

import com.pyamsoft.pydroid.util.AppDispatchers
import com.pyamsoft.tetherfi.server.ExpertPreferences
import com.pyamsoft.tetherfi.server.ServerSocketTimeout
import com.pyamsoft.tetherfi.server.broadcast.BroadcastType
import com.pyamsoft.tetherfi.server.network.PreferredNetwork
import com.pyamsoft.tetherfi.server.prereq.background.BackgroundDataGuard
import com.pyamsoft.tetherfi.server.prereq.location.LocationChecker
import com.pyamsoft.tetherfi.server.prereq.permission.PermissionGuard
import com.pyamsoft.tetherfi.server.prereq.vpn.VpnChecker
import com.pyamsoft.tetherfi.server.prereq.wifi.WifiChecker
import kotlin.test.assertEquals
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.runTest
import org.junit.Test

private class FakePermissionGuard(private val granted: Boolean) : PermissionGuard {
  override val requiredPermissions: List<String> = emptyList()

  override suspend fun canCreateNetwork(): Boolean = granted
}

private class FakeBackgroundDataGuard(private val allowed: Boolean) : BackgroundDataGuard {
  override suspend fun canCreateNetwork(): Boolean = allowed
}

private class FakeVpnChecker(private val usingVpn: Boolean) : VpnChecker {
  override suspend fun isUsingVpn(): Boolean = usingVpn
}

private class FakeLocationChecker(private val locationOn: Boolean) : LocationChecker {
  override suspend fun isLocationOn(): Boolean = locationOn
}

private class FakeWifiChecker(private val wifiOn: Boolean) : WifiChecker {
  override suspend fun isWifiOn(): Boolean = wifiOn
}

private class FakeExpertPreferences(private val broadcastType: BroadcastType) : ExpertPreferences {
  override fun listenForSocketTimeout(): Flow<ServerSocketTimeout> =
      MutableStateFlow(ServerSocketTimeout.Defaults.BALANCED)

  override fun setSocketTimeout(limit: ServerSocketTimeout) = Unit

  override fun listenForBroadcastType(): Flow<BroadcastType> = MutableStateFlow(broadcastType)

  override fun setBroadcastType(type: BroadcastType) = Unit

  override fun listenForPreferredNetwork(): Flow<PreferredNetwork> =
      MutableStateFlow(PreferredNetwork.entries.first())

  override fun setPreferredNetwork(network: PreferredNetwork) = Unit
}

private fun newRequirements(
    dispatchers: AppDispatchers,
    permissionGranted: Boolean = true,
    backgroundDataAllowed: Boolean = true,
    usingVpn: Boolean = false,
    locationOn: Boolean = true,
    wifiOn: Boolean = true,
    broadcastType: BroadcastType = BroadcastType.WIFI_DIRECT,
): AndroidHotspotRequirements =
    AndroidHotspotRequirements(
        backgroundDataGuard = FakeBackgroundDataGuard(backgroundDataAllowed),
        permissionGuard = FakePermissionGuard(permissionGranted),
        vpnChecker = FakeVpnChecker(usingVpn),
        locationChecker = FakeLocationChecker(locationOn),
        wifiChecker = FakeWifiChecker(wifiOn),
        expertPreferences = FakeExpertPreferences(broadcastType),
        dispatchers = dispatchers,
    )

class AndroidHotspotRequirementsTest {

  @Test
  fun `no blockers when everything is clear`() = runTest {
    val blockers =
        newRequirements(
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(emptySet(), blockers)
  }

  @Test
  fun `missing permission is reported as a blocker`() = runTest {
    val blockers =
        newRequirements(
                permissionGranted = false,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(setOf(HotspotStartBlocker.PERMISSION), blockers)
  }

  @Test
  fun `restricted background data is reported as a blocker`() = runTest {
    val blockers =
        newRequirements(
                backgroundDataAllowed = false,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(setOf(HotspotStartBlocker.BACKGROUND_DATA), blockers)
  }

  @Test
  fun `active vpn is reported as a blocker`() = runTest {
    val blockers =
        newRequirements(
                usingVpn = true,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(setOf(HotspotStartBlocker.VPN), blockers)
  }

  @Test
  fun `location disabled is reported as a blocker`() = runTest {
    val blockers =
        newRequirements(
                locationOn = false,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(setOf(HotspotStartBlocker.LOCATION), blockers)
  }

  @Test
  fun `wifi disabled is reported as a blocker`() = runTest {
    val blockers =
        newRequirements(
                wifiOn = false,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(setOf(HotspotStartBlocker.WIFI), blockers)
  }

  @Test
  fun `wifi disabled is not a blocker in rndis mode`() = runTest {
    val blockers =
        newRequirements(
                wifiOn = false,
                broadcastType = BroadcastType.RNDIS,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()
    assertEquals(emptySet(), blockers)
  }

  @Test
  fun `all blockers reported when everything is blocked`() = runTest {
    val blockers =
        newRequirements(
                permissionGranted = false,
                backgroundDataAllowed = false,
                usingVpn = true,
                locationOn = false,
                wifiOn = false,
                // TODO(Peter): Do we need test dispatchers?
                dispatchers = AppDispatchers.create(),
            )
            .blockers()

    assertEquals(
        setOf(
            HotspotStartBlocker.PERMISSION,
            HotspotStartBlocker.BACKGROUND_DATA,
            HotspotStartBlocker.VPN,
            HotspotStartBlocker.LOCATION,
            HotspotStartBlocker.WIFI,
        ),
        blockers,
    )
  }
}
